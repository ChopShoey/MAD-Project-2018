Hello, please do not remove or change anything in this folder, the game will break otherwise. The way the game is written and how the game engine is referenced is very finicky. So all files in this folder is essential for the game to work. Thank you for reading this!

Open angry_cats in the browser for the actual game.

Todo-List
- Add the images to the game
- Add Enemies