"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var arena_component_1 = require("./pages/arena/arena.component");
var cats_component_1 = require("./pages/cats/cats.component");
var home_component_1 = require("./pages/home/home.component");
var leaderboard_component_1 = require("./pages/leaderboard/leaderboard.component");
var settings_component_1 = require("./pages/settings/settings.component");
var sudoku_component_1 = require("./pages/sudoku/sudoku.component");
var routes = [
    // tslint:disable-next-line:max-line-length
    { path: "", redirectTo: "/home)", pathMatch: "full" },
    { path: "home", component: home_component_1.HomeComponent },
    { path: "arena", component: arena_component_1.ArenaComponent },
    { path: "cats", component: cats_component_1.CatsComponent },
    { path: "sudoku", component: sudoku_component_1.SudokuComponent },
    { path: "leaderboard", component: leaderboard_component_1.LeaderboardComponent },
    { path: "settings", component: settings_component_1.SettingsComponent }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        core_1.NgModule({
            imports: [router_1.NativeScriptRouterModule.forRoot(routes)],
            exports: [router_1.NativeScriptRouterModule]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());
exports.AppRoutingModule = AppRoutingModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLXJvdXRpbmcubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYXBwLXJvdXRpbmcubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQXlDO0FBRXpDLHNEQUF1RTtBQUN2RSxpRUFBK0Q7QUFDL0QsOERBQTREO0FBQzVELDhEQUE0RDtBQUM1RCxtRkFBaUY7QUFDakYsMEVBQXdFO0FBQ3hFLG9FQUFrRTtBQUVsRSxJQUFNLE1BQU0sR0FBVztJQUNuQiwyQ0FBMkM7SUFDM0MsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRTtJQUNyRCxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLDhCQUFhLEVBQUU7SUFDMUMsRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxnQ0FBYyxFQUFFO0lBQzVDLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsOEJBQWEsRUFBRTtJQUMxQyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLGtDQUFlLEVBQUU7SUFDOUMsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFLFNBQVMsRUFBRSw0Q0FBb0IsRUFBRTtJQUN4RCxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLHNDQUFpQixFQUFFO0NBQ3JELENBQUM7QUFNRjtJQUFBO0lBQWdDLENBQUM7SUFBcEIsZ0JBQWdCO1FBSjVCLGVBQVEsQ0FBQztZQUNOLE9BQU8sRUFBRSxDQUFDLGlDQUF3QixDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNuRCxPQUFPLEVBQUUsQ0FBQyxpQ0FBd0IsQ0FBQztTQUN0QyxDQUFDO09BQ1csZ0JBQWdCLENBQUk7SUFBRCx1QkFBQztDQUFBLEFBQWpDLElBQWlDO0FBQXBCLDRDQUFnQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcclxuaW1wb3J0IHsgUm91dGVzIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xyXG5pbXBvcnQgeyBOYXRpdmVTY3JpcHRSb3V0ZXJNb2R1bGUgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvcm91dGVyXCI7XHJcbmltcG9ydCB7IEFyZW5hQ29tcG9uZW50IH0gZnJvbSBcIi4vcGFnZXMvYXJlbmEvYXJlbmEuY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IENhdHNDb21wb25lbnQgfSBmcm9tIFwiLi9wYWdlcy9jYXRzL2NhdHMuY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IEhvbWVDb21wb25lbnQgfSBmcm9tIFwiLi9wYWdlcy9ob21lL2hvbWUuY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IExlYWRlcmJvYXJkQ29tcG9uZW50IH0gZnJvbSBcIi4vcGFnZXMvbGVhZGVyYm9hcmQvbGVhZGVyYm9hcmQuY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IFNldHRpbmdzQ29tcG9uZW50IH0gZnJvbSBcIi4vcGFnZXMvc2V0dGluZ3Mvc2V0dGluZ3MuY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IFN1ZG9rdUNvbXBvbmVudCB9IGZyb20gXCIuL3BhZ2VzL3N1ZG9rdS9zdWRva3UuY29tcG9uZW50XCI7XHJcblxyXG5jb25zdCByb3V0ZXM6IFJvdXRlcyA9IFtcclxuICAgIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTptYXgtbGluZS1sZW5ndGhcclxuICAgIHsgcGF0aDogXCJcIiwgcmVkaXJlY3RUbzogXCIvaG9tZSlcIiwgcGF0aE1hdGNoOiBcImZ1bGxcIiB9LFxyXG4gICAgeyBwYXRoOiBcImhvbWVcIiwgY29tcG9uZW50OiBIb21lQ29tcG9uZW50IH0sXHJcbiAgICB7IHBhdGg6IFwiYXJlbmFcIiwgY29tcG9uZW50OiBBcmVuYUNvbXBvbmVudCB9LFxyXG4gICAgeyBwYXRoOiBcImNhdHNcIiwgY29tcG9uZW50OiBDYXRzQ29tcG9uZW50IH0sXHJcbiAgICB7IHBhdGg6IFwic3Vkb2t1XCIsIGNvbXBvbmVudDogU3Vkb2t1Q29tcG9uZW50IH0sXHJcbiAgICB7IHBhdGg6IFwibGVhZGVyYm9hcmRcIiwgY29tcG9uZW50OiBMZWFkZXJib2FyZENvbXBvbmVudCB9LFxyXG4gICAgeyBwYXRoOiBcInNldHRpbmdzXCIsIGNvbXBvbmVudDogU2V0dGluZ3NDb21wb25lbnQgfVxyXG5dO1xyXG5cclxuQE5nTW9kdWxlKHtcclxuICAgIGltcG9ydHM6IFtOYXRpdmVTY3JpcHRSb3V0ZXJNb2R1bGUuZm9yUm9vdChyb3V0ZXMpXSxcclxuICAgIGV4cG9ydHM6IFtOYXRpdmVTY3JpcHRSb3V0ZXJNb2R1bGVdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBBcHBSb3V0aW5nTW9kdWxlIHsgfVxyXG4iXX0=